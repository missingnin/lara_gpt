<?php

return [
   'models' => 'gpt-3.5-turbo'
];
